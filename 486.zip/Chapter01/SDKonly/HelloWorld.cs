public class HelloWorld
{
	public static void Main( string[] args )
	{
		System.Console.WriteLine( "Hello world from C#" );
	}
}
